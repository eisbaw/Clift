(*
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 * Copyright (c) 2022 Apple Inc. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 *)

theory isa2014
  imports "AutoCorres2.CTranslation"
begin

install_C_file "isa2014.c"

print_locale isa2014_global_addresses

  thm f_body_def
  thm ff_body_def

end
